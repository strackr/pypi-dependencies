Flask App Builder
=================

.. image:: https://travis-ci.org/dpgaspar/Flask-AppBuilder.png?branch=master
	:target: https://travis-ci.org/dpgaspar/Flask-AppBuilder
.. image:: https://coveralls.io/repos/dpgaspar/Flask-AppBuilder/badge.png?branch=master
    :target: https://coveralls.io/r/dpgaspar/Flask-AppBuilder
.. image:: https://landscape.io/github/dpgaspar/Flask-AppBuilder/master/landscape.svg?style=flat
   :target: https://landscape.io/github/dpgaspar/Flask-AppBuilder/master
   :alt: Code Health
.. image:: https://img.shields.io/badge/pyversions-2.7%2C3.6-blue.svg
.. image:: https://badges.gitter.im/Flask-Appbuilder/Lobby.svg
   :target: https://gitter.im/dpgaspar/Flask-AppBuilder
   :alt: Join the chat at

Simple and rapid application development framework, built on top of `Flask <http://flask.pocoo.org/>`_.
includes detailed security, auto CRUD generation for your models, google charts and much more.

Extensive configuration of all functionality, easily integrate with normal Flask/Jinja2 development.

Take a look at installation, quick how to tutorials, API reference etc: `Documentation <http://flask-appbuilder.readthedocs.org/en/latest/>`_

Checkout installation video on `YouTube <http://youtu.be/xvum4vfwldg>`_

Lots of `examples <https://github.com/dpgaspar/Flask-AppBuilder/tree/master/examples>`_ and a live quick how to `Demo from the docs <http://flaskappbuilder.pythonanywhere.com/>`_ (login has guest/welcome).

Package Version
---------------

*New 1.12.2*.

BREAKING CHANGES relative to 1.12.0: we have bumped flask-login version, this causes breaking changes on the API relative to this package.

- Flask-AppBuilder version <= 1.11.1 was using Flask-Login 0.2.X.

- Flask-AppBuilder version > 1.12.0 is using Flask-Login > 0.3.X.

The following methods from Flask-Login changed to properties:

- is_anonymous() -> is_anonymous

- is_active() -> is_active

- is_authenticated() -> is_authenticated

Take at look at: https://github.com/maxcountryman/flask-login/blob/master/CHANGES#L49

Also read the `Versions <http://flask-appbuilder.readthedocs.org/en/latest/versions.html>`_ for further detail on what changed.

Fixes, Bugs and contributions
-----------------------------

You're welcome to report bugs, propose new features, or even better contribute to this project.

`Issues, bugs and new features <https://github.com/dpgaspar/Flask-AppBuilder/issues/new>`_

`Contribute <https://github.com/dpgaspar/Flask-AppBuilder/fork>`_

The tests can be run locally (provided Docker and Docker-Compose are installed) by running
`docker-compose run --rm test`

Or, if you have mongodb and the requirements installed locally-
`setup.py test`


Projects/Organizations using FAB
--------------------------------

If you would like to share your project, or let everyone know that you're using FAB on your organization please submit a PR or send me an email with the details. 

Projects:

- `Superset <https://github.com/airbnb/superset>`_ - a data exploration platform designed to be visual, intuitive, and interactive

Organizations:

- Airbnb
- Miniclip
- EuroBIC

Includes:
---------

  - Database
      - SQLAlchemy, multiple database support: sqlite, MySQL, ORACLE, MSSQL, DB2 etc.
      - Partial support for MongoDB using MongoEngine.
      - Multiple database connections support (Vertical partitioning).
      - Easy mixin audit to models (created/changed by user, and timestamps).
  - Security
      - Automatic permissions lookup, based on exposed methods. It will grant all permissions to the Admin Role.
      - Inserts on the Database all the detailed permissions possible on your application.
      - Public (no authentication needed) and Private permissions.
      - Role based permissions.
      - Authentication support for OAuth, OpenID, Database, LDAP and REMOTE_USER environ var.
      - Support for self user registration.
  - Views and Widgets
      - Automatic menu generation.
      - Automatic CRUD generation.
      - Multiple actions on db records.
      - Big variety of filters for your lists.
      - Various view widgets: lists, master-detail, list of thumbnails etc
      - Select2, Datepicker, DateTimePicker
      - Related Select2 fields.
      - Google charts with automatic group by or direct values and filters.
      - AddOn system, write your own and contribute.
  - Forms
      - Automatic, Add, Edit and Show from Database Models
      - Labels and descriptions for each field.
      - Automatic base validators from model's definition.
      - Custom validators, extra fields, custom filters for related dropdown lists.
      - Image and File support for upload and database field association. It will handle everything for you.
      - Field sets for Form's (Django style).
  - i18n
      - Support for multi-language via Babel
  - Bootstrap 3.1.1 CSS and js, with Select2 and DatePicker
  - Font-Awesome icons, for menu icons and actions.


Some pictures
-------------

Login page (with AUTH_DB)

.. image:: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/login_db.png
    :width: 480px
    :target: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/login_db.png


Login page (with AUTH_OAUTH)

.. image:: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/login_oauth.png
    :width: 480px
    :target: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/login_oauth.png


Security

.. image:: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/security.png
    :width: 480px
    :target: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/security.png


Lists:

List contacts example

.. image:: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/contact_list.png
    :width: 480px
    :target: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/contact_list.png


List Group example with search

.. image:: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/group_list.png
    :width: 480px
    :target: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/group_list.png



Charts:

Group by pie chart

.. image:: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/grouped_chart.png
    :width: 480px
    :target: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/grouped_chart.png

Direct time chart

.. image:: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/direct_chart.png
    :width: 480px
    :target: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/chart_time1.png

Group by time chart

.. image:: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/chart_time2.png
    :width: 480px
    :target: https://raw.github.com/dpgaspar/flask-AppBuilder/master/images/chart_time2.png


Depends on:
-----------

- flask
- click
- colorama
- flask-sqlalchemy
- flask-login
- flask-openid
- flask-wtform
- flask-Babel

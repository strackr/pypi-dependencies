# -*- coding: utf-8 -*-

VERSION = "2019.2"

OLSON_VERSION = "2019b"
